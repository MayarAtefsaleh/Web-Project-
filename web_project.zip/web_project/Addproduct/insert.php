<?php
include('db.php');
include('function.php');
if(isset($_POST["operation"]))
{
 if($_POST["operation"] == "Add")
 {
  $image = '';
  if($_FILES["product_image"]["name"] != '')
  {
   $image = upload_image();
  }
  $statement = $connection->prepare("
   INSERT INTO product (price, description, image) 
   VALUES (:price, :description, :image)
  ");
  $result = $statement->execute(
   array(
    ':price' => $_POST["price"],
    ':description' => $_POST["description"],
    ':image'  => $image
   )
  );
  if(!empty($result))
  {
   echo 'Data Inserted';
  }
 }
 if($_POST["operation"] == "Edit")
 {
  $image = '';
  if($_FILES["product_image"]["name"] != '')
  {
   $image = upload_image();
  }
  else
  {
   $image = $_POST["hidden_pro_image"];
  }
  $statement = $connection->prepare(
   "UPDATE product 
   SET price = :price, description = :description, image = :image  
   WHERE id = :id
   "
  );
  $result = $statement->execute(
   array(
    ':price' => $_POST["price"],
    ':description' => $_POST["description"],
    ':image'  => $image,
    ':id'   => $_POST["product_id"]
   )
  );
  if(!empty($result))
  {
   echo 'Data Updated';
  }
 }
}

?>